import reflex as rx

config = rx.Config(
    app_name="reflex_dashboard",
    db_url="sqlite:///qademo.db",
)
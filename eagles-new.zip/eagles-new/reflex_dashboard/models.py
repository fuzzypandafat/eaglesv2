import reflex as rx

from typing import Optional, List
from sqlmodel import Field, SQLModel, create_engine, Session, select, Relationship


class User(rx.Model, table=True):   # Define a SQLModel class
    # id: Optional[int] = Field(default=None, primary_key=True)   # Define a primary key column
    # name: str
    # email: str
    
    id: int = Field(default=None, primary_key=True)
    full_name: str              #need to check if change of variable name effects used full_name instead of name
    mobile_number: str
    email: str
    password: str
    salt: str
    ## Define a relationship between the User and Workspace classes (one-to-many)
    workspaces: List["Workspace"] = Relationship(back_populates="user") # Define a relationship between the User and Workspace classes (one-to-many)


    
    
    # # a user has many workspaces
    # workspaces: List["Workspace"] = Relationship(back_populates="user") # Define a relationship between the User and Workspace classes (one-to-many)

class Workspace(rx.Model, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    
    #a workspace belongs to a user
    user_id: int = Field(foreign_key="user.id") # Define a foreign key relationship between the Workspace and User classes
    user: User = Relationship(back_populates="workspaces") # Define a relationship between the Workspace and User classes (many-to-one)
    
    #a workspace has many projects
    projects: List["Project"] = Relationship(back_populates="workspace") # Define a relationship between the Workspace and Project classes (one-to-many)

class Project(rx.Model, table=True):   # Define a SQLModel class                         
    id: Optional[int] = Field(default=None, primary_key=True) 
    name: str
    description: Optional[str] = None
    
    #a project belongs to a workspace
    workspace_id: int = Field(foreign_key="workspace.id") # Define a foreign key relationship between the Project and Workspace classes
    workspace: Workspace = Relationship(back_populates="projects") # Define a relationship between the Project and Workspace classes (many-to-one)
   
    #a project has many collections
    collections: List["Collection"] = Relationship(back_populates="project") # Define a relationship between the Project and Collection classes (one-to-many)

class Collection(rx.Model, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    
    #a collection belongs to a project
    project_id: int = Field(foreign_key="project.id")   # Define a foreign key relationship between the Collection and Project classes
   
    project : Project = Relationship(back_populates="collections") # Define a relationship between the Collection and Project classes (many-to-one)
   
    #a collection has many doc_files
    doc_files : List["Doc_file"] = Relationship(back_populates="collection")  

class Doc_file(rx.Model, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    file_path: str
    des: Optional[str] = None
    
    #a doc_file belongs to a collection
    collection_id: int = Field(foreign_key="collection.id") # Define a foreign key relationship between the Doc_files and Collection classes
    collection : Collection = Relationship(back_populates="doc_files") # Define a relationship between the Doc_files and Collection classes (many-to-one)
    

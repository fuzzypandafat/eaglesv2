async def rag_process_question_old(self, question: str):
        """Get the response from the API.

        Args:
            form_data: A dict with the current question.
        """

        # Add the question to the list of questions.
        qa = QA(question=question, answer="")
        self.chats[self.current_chat].append(qa)

        # Clear the input and start the processing.
        self.processing = True
        yield
        
        """
        Adding code for getting doctument form chroma collection
        
        """
        
        #embedding_function = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
        persistent_client = chromadb.PersistentClient("./vector_store")
        persist_directory = './vector_store'
        embedding_function = embedding_functions.OpenAIEmbeddingFunction(api_key=OPENAI_API_KEY,model_name="text-embedding-3-small")
        llm = ChatOpenAI(model="gpt-3.5-turbo")
        client = chromadb.Client()
        collection = client.get_collection(name="egales3_pdf")
        
        docs = collection.query(
            query_texts=[question],
            include=["documents"]
        )
        
        
        #vectordb = Chroma(collection_name="egales3_pdf",persist_directory=persist_directory, embedding_function=embedding_function)
        #retriever = vectordb.as_retriever(search_type="similarity", search_kwargs={"k": 4})
        
        
        context = self.format_docs(docs)
            
     

      #  docs = langchain_chroma.similarity_search(question)
        template_new = f"Use the following pieces of context to answer the question at the end. 
        If you don't know the answer, just say that you don't know, don't try to make up an answer. 
        Use three sentences maximum. Keep the answer as concise as possible.Always return answer in 
        markdown format. 
        {context}
        Question: {question}
        Helpful Answer:"""
        
        template = """Use the following pieces of context to answer the question at the end. 
        If you don't know the answer, just say that you don't know, don't try to make up an answer. 
        Use three sentences maximum. Keep the answer as concise as possible. 
        Always return answer in markdown format. 
        {context}
        Question: {question}
        Helpful Answer:"""
        QA_CHAIN_PROMPT = PromptTemplate(input_variables=["context", "question"],template=template,)
        qa_chain = RetrievalQA.from_chain_type(llm,
                                       retriever=retriever,
                                       return_source_documents=True,
                                       chain_type_kwargs={"prompt": QA_CHAIN_PROMPT})        
        
        async for chunk in qa_chain.astream(question):
            print(chunk["result"], end="|", flush=True)
            if chunk["result"] is not None:
                    self.chats[self.current_chat][-1].answer += chunk["result"]
            else:
                answer_text = ""
                self.chats[self.current_chat][-1].answer += answer_text
            self.chats = self.chats
            yield    
        self.processing = False 
     

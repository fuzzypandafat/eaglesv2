import reflex as rx
from reflex_dashboard.state import State

def handle_signup_click():
    return rx.redirect('/signUpPage')

def logina():
    return rx.box(
        rx.vstack(
            rx.center(
                rx.image(
                    src="/logos.webp",
                    width="10em",
                    height="auto",
                    border_radius="25%",
                ),
                rx.heading(
                    "Sign in to your account",
                    size="6",
                    as_="h2",
                    text_align="center",
                    width="100%",
                ),
                direction="column",
                spacing="5",
                width="100%",
            ),
            rx.vstack(
                rx.cond(
                    State.error_message_log,
                    rx.text(State.error_message_log,
                        color="red",
                        size="4",
                        weight="medium",
                        text_align="left",
                        width="100%",
                    ),
                ),
                rx.text(
                    "Email address",
                    size="3",
                    weight="medium",
                    text_align="left",
                    width="100%",
                ),
                rx.input(
                    placeholder="user@reflex.dev",
                    type="email",
                    size="3",
                    width="100%",
                    on_change=State.set_email_log,
                ),
                justify="start",
                spacing="2",
                width="100%",
            ),
            rx.vstack(
                rx.hstack(
                    rx.text(
                        "Password",
                        size="3",
                        weight="medium",
                    ),
                    rx.link(
                        "Forgot password?",
                        href="/forgetpass",
                        size="3",
                    ),
                    justify="between",
                    width="100%",
                ),
                rx.input(
                    placeholder="Enter your password",
                    type="password",
                    size="3",
                    width="100%",
                    on_change=State.set_password_log,
                ),
                spacing="2",
                width="100%",
            ),
            rx.button(
                "Sign in",
                size="3",
                width="100%",
                on_click=State.handle_login_submit,
            ),
            rx.center(
                rx.text("New here?", size="3"),
                rx.link("Sign up", size="3", on_click=handle_signup_click),
                opacity="0.8",
                spacing="2",
                direction="row",
            ),
            spacing="6",
            width="100%",
            max_width="28em",
            margin="0 auto",
        ),
        width="100%",
        height="100vh",
        bg="white",
    )
import reflex as rx
from reflex_dashboard.state import State

def navbar_link(text: str, url: str) -> rx.Component:
    return rx.link(
        rx.text(text, size="5", weight="medium"),
        href=url,
        color="gray.800",
        _hover={"color": "blue.500"},
    )

def handle_login_click():
    return rx.redirect('/loginpage')

def handle_signup_click():
    return rx.redirect('/signUpPage')

def navbar():
    return rx.box(
        rx.hstack(
            rx.box(
                rx.image(src='/logos.webp', width='70px'),
                flex_shrink=0,
                margin_left="10px",
            ),
            rx.spacer(),
            rx.hstack(
                navbar_link("Home", "/"),
                navbar_link("Indexed files", "/home/"),
                navbar_link("Ask", "/ask"),
                navbar_link("Files", "/files"),
                justify="between",
                width="50%",
            ),
            rx.spacer(),
            rx.hstack(
                rx.button(
                    "Sign Up",
                    size="3",
                    variant="outline",
                    on_click=handle_signup_click,
                ),
                rx.button("Log In", size="3", margin_right="15px", on_click=handle_login_click),
                spacing="4",
            ),
            width="100%",
            justify="between",
            align="center",
            padding_y="5",
            padding_x="5",
            max_width="1600px",
            margin="0 auto",
        ),
        width="100vw",
        position="sticky",
        top="0",
        z_index="999",
        bg="white",
        border_color="gray.200",
        margin_left="calc(-50vw + 50%)",
        margin_right="calc(-50vw + 50%)",
        box_shadow="0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)"  # Added shadow
    )

def home():
    return rx.box(
        navbar(),
        rx.vstack(
            rx.text("Main content goes here"),
            rx.text("Scroll down to see the navbar behavior"),
            rx.vstack(
                *[rx.text(f"Content {i}") for i in range(1, 51)],
                spacing="4",
            ),
            padding="2em",
            width="100%",
            max_width="1600px",
            margin="0 auto",
        ),
        width="100%",
        overflow_x="hidden",
    )
import reflex as rx
from reflex_dashboard.state import State


def parse_file():
    return rx.card(
        rx.flex(
            rx.vstack(
                    rx.text(f"File to be parsed ==> {State.currentParsingFileName}",size="4",weight="bold",color_scheme="green"),
                    rx.text_area(
                    value=State.fileText,
                    on_change=State.set_fileText,
                    placeholder="",
                    style={"height": "500px", "width": "730px"}
                ),
                rx.hstack(
                    rx.text("Embedding in vector DB", size="2"),
                    rx.switch(size="1", default_checked=True),
                    rx.text("Search Index", size="2"),
                    rx.switch(size="1", default_checked=False),
                    rx.text("Store in postgres db", size="2"),
                    rx.switch(size="1", default_checked=False),
                    rx.text("Store in mongo db", size="2"),
                    rx.switch(size="1", default_checked=False),
                     justify="end",
                     spacing="2"
                ),
            ),

            rx.grid(
                rx.button("Start Processing", color_scheme="purple",on_click=State.update_text,cursor="pointer",),
                rx.button(
                    "Save Embedding",
                    on_click=State.update_text ,
                    cursor="pointer",                  
                ),
                 rx.button(
                    "Update Embedding",
                    on_click=State.update_text,
                    color_scheme="orange",
                    cursor="pointer",                   
                ),
                columns="3",
                spacing="2",
            ),
            direction="column",
            spacing="2",
        ),
        style={"width": "100%", "height": "100%"},
    )

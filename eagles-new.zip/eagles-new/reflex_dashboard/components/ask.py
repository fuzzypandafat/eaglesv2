import reflex as rx

from reflex_dashboard.components import loading_icon
from reflex_dashboard.chatState import QA, chatState

message_style = dict(
    display="inline-block",
    padding="1em",
    border_radius="12px",
    max_width=["30em", "30em", "50em", "50em", "50em", "50em"],
    box_shadow="0 2px 4px rgba(0,0,0,0.1)",
)

def message(qa: QA) -> rx.Component:
    return rx.box(
        rx.box(
            rx.markdown(
                qa.question,
                background_color=rx.color("mauve", 4),
                color=rx.color("mauve", 12),
                **message_style,
            ),
            text_align="right",
            margin_top="1em",
        ),
        rx.box(
            rx.markdown(
                qa.answer,
                background_color=rx.color("accent", 4),
                color=rx.color("accent", 12),
                **message_style,
            ),
            text_align="left",
            padding_top="1em",
        ),
        width="100%",
    )

def chat() -> rx.Component:
    return rx.container(
        rx.vstack(
            rx.box(rx.foreach(chatState.chats[chatState.current_chat], message), width="100%"),
            py="8",
            flex="1",
            width="100%",
            max_width="50em",
            padding_x="1px",
            align_self="center",
            overflow="hidden",
            padding_bottom="2em",
        )
    )

def action_bar() -> rx.Component:
    return rx.center(
        rx.vstack(
            rx.box(
                rx.vstack(
                    rx.heading("EaglesGPT", size="4", color=rx.color("mauve", 12)),
                    rx.chakra.form(
                        rx.chakra.form_control(
                            rx.hstack(
                                rx.radix.text_field.root(
                                    rx.radix.text_field.input(
                                        placeholder="Type something...",
                                        id="question",
                                        width=["15em", "20em", "45em", "50em", "50em", "50em"],
                                    ),
                                    rx.radix.text_field.slot(
                                        rx.tooltip(
                                            rx.icon("info", size=18),
                                            content="Enter a question to get a response.",
                                        )
                                    ),
                                ),
                                rx.button(
                                    rx.cond(
                                        chatState.processing,
                                        loading_icon.loading_icon(height="1em"),
                                        rx.text("Send"),
                                    ),
                                    type="submit",
                                    size="3",
                                    color_scheme="blue",
                                ),
                                align_items="center",
                                width="100%",
                            ),
                            is_disabled=chatState.processing,
                        ),
                        on_submit=chatState.process_question,
                        reset_on_submit=True,
                        width="100%",
                    ),
                    spacing="4",
                    align_items="center",
                    width="100%",
                ),
                padding="1em",
                border_radius="lg",
                border="1px solid",
                border_color=rx.color("mauve", 6),
                background_color=rx.color("mauve", 1),
                width="100%",
            ),
            rx.text(
                "EaglesGPT may return factually incorrect or misleading responses. Use discretion.",
                text_align="center",
                font_size=".75em",
                color=rx.color("mauve", 10),
            ),
            rx.text(
                "Made with love at Eagles AI Group, BFSI, Kolkata",
                text_align="center",
                font_size=".75em",
                color=rx.color("mauve", 10),
            ),
            align_items="center",
            width="100%",
            max_width="50em",
            spacing="4",
        ),
        position="sticky",
        bottom="0",
        left="0",
        padding_y="16px",
        backdrop_filter="auto",
        backdrop_blur="lg",
        border_top=f"1px solid {rx.color('mauve', 3)}",
        background_color=rx.color("mauve", 2),
        align_items="stretch",
        width="100%",
    )

def index() -> rx.Component:
    return rx.box(
        chat(),
        action_bar(),
        height="100vh",
        overflow="hidden",
    )
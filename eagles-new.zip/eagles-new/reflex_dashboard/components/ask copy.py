import reflex as rx

from reflex_dashboard.components import loading_icon
from reflex_dashboard.chatState import QA, chatState

message_style = dict(display="inline-block", padding="em", border_radius="8px",
                     max_width=["30em", "30em", "50em", "50em", "50em", "50em"])


def message(qa: QA) -> rx.Component:
    """A single question/answer message.

    Args:
        qa: The question/answer pair.

    Returns:
        A component displaying the question/answer pair.
    """
    return rx.box(
        rx.box(
            rx.markdown(
                qa.question,
                background_color=rx.color("mauve", 4),
                color=rx.color("mauve", 12),
                **message_style,
            ),
            text_align="right",
            margin_top="1em",
        ),
        rx.box(
            rx.markdown(
                qa.answer,
                background_color=rx.color("accent", 4),
                color=rx.color("accent", 12),
                **message_style,
            ),
            text_align="left",
            padding_top="1em",
        ),
        width="100%",
    )


def chat() -> rx.Component:
    """List all the messages in a single conversation."""
    return rx.container(
        rx.vstack(
            rx.box(rx.foreach(chatState.chats[chatState.current_chat], message), width="100%"),
            py="8",
            flex="1",
            width="100%",
            max_width="50em",
            padding_x="1px",
            align_self="center",
            overflow="hidden",
            padding_bottom="2em",
        )
    )


def action_bar() -> rx.Component:
    """The action bar to send a new message."""
    return rx.center(
        rx.vstack(
            rx.chakra.form(
                rx.chakra.form_control(
                    rx.hstack(
                        rx.radix.text_field.root(
                            rx.radix.text_field.input(
                                placeholder="Type something...",
                                id="question",
                                width=["15em", "20em", "45em", "50em", "50em", "50em"],
                            ),
                            rx.radix.text_field.slot(
                                rx.tooltip(
                                    rx.icon("info", size=18),
                                    content="Enter a question to get a response.",
                                )
                            ),
                        ),
                        rx.button(
                            rx.cond(
                                chatState.processing,
                                loading_icon.loading_icon(height="1em"),
                                rx.text("Send"),
                            ),
                            type="submit",
                            size="3"
                        ),
                        align_items="center",
                    ),
                    is_disabled=chatState.processing,
                ),
                on_submit=chatState.process_question,
                reset_on_submit=True,
            ),
            rx.text(
                "EaglesGPT may return factually incorrect or misleading responses. Use discretion.",
                text_align="center",
                font_size=".75em",
                color=rx.color("mauve", 10),
            ),
            rx.text("Made in love at Eagales AI Goup,BFSI,Kolkata"),
            align_items="center",
        ),
        position="sticky",
        bottom="0",
        left="0",
        padding_y="16px",
        backdrop_filter="auto",
        backdrop_blur="lg",
        border_top=f"1px solid {rx.color('mauve', 3)}",
        background_color=rx.color("mauve", 2),
        align_items="stretch",
        width="100%",
    )

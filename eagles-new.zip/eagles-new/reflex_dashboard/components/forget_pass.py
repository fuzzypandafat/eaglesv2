import reflex as rx

from reflex_dashboard.state import State

def handle_login_click():
    return rx.redirect('/setpassword')

def forgetbox():
    return rx.box(
        rx.vstack(
            rx.center(
                rx.image(
                    src="/logos.webp",
                    width="10em",
                    height="auto",
                    border_radius="25%",
                ),
                rx.heading(
                    "Forgot Password",
                    size="6",
                    as_="h2",
                    text_align="center",
                    width="100%",
                ),
                direction="column",
                spacing="5",
                width="100%",
            ),
            rx.vstack(
                rx.cond(
                    State.reset_error_message,
                    rx.text(State.reset_error_message,
                        color="red",
                        size="4",
                        weight="medium",
                        text_align="left",
                        width="100%",
                    ),
                ),
                rx.text(
                    "Enter Your Email address",
                    size="3",
                    weight="medium",
                    text_align="left",
                    width="100%",
                ),
                rx.input(
                    type="email",
                    size="3",
                    width="100%",
                    on_change=State.set_email_forget,
                ),
                justify="start",
                spacing="2",
                width="100%",
            ),
            rx.button(
                "Submit",
                size="3",
                width="100%",
                on_click=State.handle_email_verification,
            ),
            rx.center(
                rx.text("Remember your password?", size="3"),
                rx.link("Back to Login", size="3", on_click=handle_login_click),
                opacity="0.8",
                spacing="2",
                direction="row",
            ),
            spacing="6",
            width="100%",
            max_width="28em",
            margin="0 auto",
        ),
        width="100%",
        height="100vh",
        bg="white",
    )

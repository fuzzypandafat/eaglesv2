import reflex as rx

from reflex_dashboard.state import State

def handle_back_to_login():
    return rx.redirect('/loginpage')

def setbox():
    return rx.box(
        rx.vstack(
            rx.center(
                rx.image(
                    src="/logos.webp",
                    width="10em",
                    height="auto",
                    border_radius="25%",
                ),
                rx.heading(
                    "Set New Password",
                    size="6",
                    as_="h2",
                    text_align="center",
                    width="100%",
                ),
                direction="column",
                spacing="5",
                width="100%",
            ),
            rx.vstack(
                rx.cond(
                    State.error_message_set,
                    rx.text(State.error_message_set,
                        color="red",
                        size="4",
                        weight="medium",
                        text_align="left",
                        width="100%",
                    ),
                ),
                rx.text(
                    "Enter New Password",
                    size="3",
                    weight="medium",
                    text_align="left",
                    width="100%",
                ),
                rx.input(
                    type="password",
                    size="3",
                    width="100%",
                    on_change=State.set_password_set
                ),
                rx.cond(
                    State.password_set_error_message,
                    rx.text(State.password_set_error_message,
                        color="red",
                        size="3",
                        weight="medium",
                        text_align="left",
                        width="100%",
                    ),
                ),
                rx.text(
                    "Confirm your Password",
                    size="3",
                    weight="medium",
                    text_align="left",
                    width="100%",
                ),
                rx.input(
                    type="password",
                    size="3",
                    width="100%",
                    on_change=State.set_confirm_password_set
                ),
                justify="start",
                spacing="2",
                width="100%",
            ),
            rx.vstack(
                rx.hstack(
                    rx.text(
                        "Password Requirements",
                        size="3",
                        weight="medium",
                    ),
                    rx.link(
                        "Need help?",
                        href="/help",
                        size="3",
                    ),
                    justify="between",
                    width="100%",
                ),
                rx.text(
                    "• At least 8 characters long\n• Contains uppercase and lowercase letters\n• Includes numbers and special characters",
                    size="2",
                    color="gray",
                    width="100%",
                ),
                spacing="2",
                width="100%",
            ),
            rx.button(
                "Submit",
                size="3",
                width="100%",
                on_click=State.handle_setpass_submit
            ),
            rx.center(
                rx.text("Remember your password?", size="3"),
                rx.link("Back to Login", size="3", on_click=handle_back_to_login),
                opacity="0.8",
                spacing="2",
                direction="row",
            ),
            spacing="6",
            width="100%",
            max_width="28em",
            margin="0 auto",
        ),
        width="100%",
        height="100vh",
        bg="white",
    )
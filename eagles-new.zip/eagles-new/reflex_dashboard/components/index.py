"""The main index page."""

import reflex as rx
from reflex_dashboard.state import State
from reflex_dashboard.navigation import main_navbar
from reflex_dashboard.template import template

# Content in a grid layout.
color = "rgb(107,99,246)"


def _header_cell(text: str, icon: str):
    return rx.table.column_header_cell(
        rx.hstack(
            rx.icon(icon, size=18),
            rx.text(text),
            align="center",
            spacing="2",
        ),
    )


@template
def index() -> rx.Component:
    return rx.container(
        main_navbar("Welcome to EAGAL's AI Generative Platform"),
        rx.hstack(
            rx.box(
                rx.text("List of Indexed files.", size="4"),
                width="100%",

            ),
            rx.box(
                rx.button(
                    rx.icon(tag="message-square-plus"),
                    "Ask", on_click=rx.redirect("/ask"),
                    color_scheme="indigo",
                    size="3",
                    cursor="pointer",
                    variant="solid",
                    width="100%"
                )
            )
            , distance="between",
            padding="2em"
        ),
        rx.divider(),
        rx.table.root(
            rx.table.header(
                rx.table.row(
                    _header_cell("File Name", "file"),
                    _header_cell("File Type", "file"),
                    _header_cell("File Size", "file"),
                    _header_cell("Action", "file"),
                ),
                style={"_hover": {"bg": rx.color("gray", 3)}},
                align="center",
            ),
            rx.foreach(State.indexedFiles, lambda ufiles:
            rx.table.body(
                rx.table.row(
                    rx.table.row_header_cell(
                        rx.link(ufiles.name,
                                href=rx.get_upload_url(ufiles.name),
                                weight="bold",
                                is_external=True)),
                    rx.table.cell(ufiles.type.split("/")[1]),
                    rx.table.cell(ufiles.size),
                    rx.table.cell(
                        rx.icon_button(
                            rx.icon("trash-2", size=22),
                            on_click=lambda: State.delete_file(getattr(ufiles, "id")),
                            size="2",
                            variant="solid",
                            color_scheme="red",
                            cursor="pointer"
                        )),

                ))
                       ),
            variant="surface",
            size="3",
            width="100%",

        ),
        size="3",
        margin_top="calc(100px + 2em)",
        padding="3em",
    )

import reflex as rx

def container_with_image_and_text(img_src, text):
    return rx.chakra.container(
        rx.vstack(
            rx.image(src=img_src),
            rx.text(text),
            spacing="2",
            align="center"
        ),
        center_content=True,
        bg="white",
        width="100%",
        padding="1em",
        border_radius="15px",
        border_color="lightgrey",
        border_width="1px",
        box_shadow="0 4px 8px rgba(0, 0, 0, 0.1)",
    )

def icon_with_text(tag, text):
    return rx.vstack(
        rx.icon(tag=tag, size=24),
        rx.text(text, size="4"),
        align="center",
        spacing="5",
        justify_content="space-between",
        margin_left="150px",
        margin_right="150px",
    )

def row_with_icon_heading_text(icon_tag, heading_text, sentence):
    return rx.box(
        rx.hstack(
            rx.icon(tag=icon_tag, size=24),
            rx.box(
                rx.heading(heading_text, size="4", weight="medium"),
                rx.text(sentence, size="3"),
                align="start"
            ),
            spacing="4",
            align="center"
        ),
        border_bottom="1px solid lightgrey",
        padding="1em",
    )

def handle_signup_click():
    return rx.redirect('/signUpPage')

def home():
    return rx.box(
        rx.box(
            rx.vstack(
                rx.hstack(
                    rx.box(
                        rx.heading(
                            "Manage Your Financial Projects",
                            size="9",
                            weight="bold",
                            margin_bottom="22px"
                        ),
                        rx.heading(
                            "Effortlessly with EagleGPT",
                            size="9",
                            weight="bold"
                        ),
                        align_items="center",
                        justify_content="center",
                        width="100%",
                        text_align="center",
                        margin_top="12vh",
                    ),
                    width="100%",
                    justify_content="center",
                    size="4",
                ),
                rx.box(
                    rx.text(
                        "Upload, organize, and analyze your financial documents with our comprehensive AI-driven solution.",
                        size="4",
                        weight="bold",
                        color="gray"
                    ),
                    align_items="center",
                    justify_content="center",
                    text_align="center",
                    margin_top="50px",
                ),
                rx.hstack(
                    rx.button(
                        "SIGN UP",
                        color_scheme="green",
                        size="3",
                        on_click=handle_signup_click,
                    ),
                    rx.button(
                        "CONTACT US",
                        color_scheme="green",
                        size="3"
                    ),
                    spacing="4",
                    margin_top="25px",
                    justify="center",
                    align="center",
                    width="100%",
                ),
                rx.hstack(
                    container_with_image_and_text("/img1.webp", "Create multiple workspaces for different projects."),
                    container_with_image_and_text("/img2.webp", "Upload and manage your financial files securely."),
                    container_with_image_and_text("/img3.webp", "Use AI to query and analyze your financial data."),
                    spacing="2",
                    width="100%",
                    margin_top="75px",
                ),
                rx.hstack(
                    icon_with_text("folder", "Workspaces"),
                    icon_with_text("upload", "Upload Files"),
                    icon_with_text("bar_chart", "Analyze Data"),
                    spacing="4",
                    justify="center",
                    width="100%",
                    margin_top="75px",
                ),
                rx.hstack(
                    rx.heading(
                        "Advanced Document Management with FinDocCloud",
                        size="7",
                        weight="bold",
                        margin_bottom="22px",
                        width="40%",
                        align_items="top",
                    ),
                    rx.vstack(
                        rx.heading(
                            "Transform How You Handle Financial Documents",
                            size="7",
                            weight="bold"
                        ),
                        rx.text(
                            "Our solution simplifies the process of managing financial documents, ensuring clarity and accuracy for better decision-making. FinDocCloud is designed to handle various types of financial documents.",
                            size="4",
                            weight="bold",
                            color="gray"
                        ),
                        rx.heading(
                            "Key Features",
                            size="6",
                            weight="bold",
                            margin_top="22px",
                        ),
                        rx.hstack(
                            container_with_image_and_text("/img1.webp", "Automated parsing of financial documents."),
                            container_with_image_and_text("/img2.webp", "Collaborative workspace for your team."),
                            spacing="2",
                            margin_top="25px",
                        ),
                        width="60%"
                    ),
                    text_align="left",
                    margin_top="12vh",
                    size="4",
                ),
                rx.hstack(
                    rx.box(
                        rx.heading(
                            "Efficient Financial Document Management",
                            size="7",
                            weight="bold",
                            margin_bottom="22px",
                            align_items="top",
                        ),
                        rx.text(
                            "Handle your financial documents with ease and precision. Our solution supports a wide range of document types and provides tools for effective management.",
                            size="4",
                            weight="bold",
                            color="gray"
                        ),
                        rx.button(
                            "CONTACT US",
                            color_scheme="green",
                            size="3",
                            margin_top="25px",
                        ),
                        width="45%"
                    ),
                    rx.vstack(
                        rx.vstack(
                            row_with_icon_heading_text("folder", "Create Workspaces", "Set up workspaces for different projects and teams."),
                            row_with_icon_heading_text("upload", "Upload Files", "Securely upload and manage your financial files."),
                            row_with_icon_heading_text("bar_chart", "Analyze Data", "Leverage AI to analyze and query your financial data."),
                            row_with_icon_heading_text("settings", "Manage Settings", "Customize your workspace settings."),
                            spacing="4",
                            width="100%",
                            align="start",
                        ),
                        width="55%"
                    ),
                    text_align="left",
                    margin_top="12vh",
                    size="4",
                ),
            ),
        ),
        width="100%",  # Ensure the outermost box takes full width
    )

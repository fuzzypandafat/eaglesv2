import reflex as rx

def footer_item(text: str, href: str) -> rx.Component:
    return rx.link(rx.text(text, size="3"), href=href, color="gray.600", _hover={"color": "blue.500"})

def footer_items_1() -> rx.Component:
    return rx.vstack(
        rx.heading("PRODUCTS", size="4", weight="bold", as_="h3"),
        footer_item("Web Design", "/#"),
        footer_item("Web Development", "/#"),
        # footer_item("E-commerce", "/#"),
        # footer_item("Content Management", "/#"),
        # footer_item("Mobile Apps", "/#"),
        align_items=["center", "center", "start"],
        spacing="4",
    )

def footer_items_2() -> rx.Component:
    return rx.vstack(
        rx.heading("RESOURCES", size="4", weight="bold", as_="h3"),
        footer_item("Blog", "/#"),
        footer_item("Case Studies", "/#"),
        # footer_item("Whitepapers", "/#"),
        # footer_item("Webinars", "/#"),
        # footer_item("E-books", "/#"),
        align_items=["center", "center", "start"],
        spacing="4",
    )

def social_link(icon: str, href: str) -> rx.Component:
    return rx.link(rx.icon(icon), href=href, color="gray.600", _hover={"color": "blue.500"})

def socials() -> rx.Component:
    return rx.hstack(
        social_link("instagram", "/#"),
        social_link("twitter", "/#"),
        social_link("facebook", "/#"),
        social_link("linkedin", "/#"),
        spacing="3",
    )

def footer() -> rx.Component:
    return rx.box(
        rx.vstack(
            rx.flex(
                rx.hstack(
                    rx.image(
                        src="/logos.webp",
                        width="2.25em",
                        height="auto",
                        border_radius="25%",
                    ),
                    rx.vstack(
                        rx.heading(
                            "City",
                            size="7",
                            weight="bold",
                        ),
                        rx.text(
                            "© 2024 City, Inc",
                            size="3",
                            white_space="nowrap",
                            weight="medium",
                        ),
                        spacing="1",
                        align_items="start",
                    ),
                    align_items="center",
                    spacing="4",
                ),
                footer_items_1(),
                footer_items_2(),
                justify="between",
                spacing="6",
                flex_direction=["column", "column", "row"],
                width="100%",
            ),
            rx.divider(),
            rx.flex(
                rx.hstack(
                    footer_item("Privacy Policy", "/#"),
                    footer_item("Terms of Service", "/#"),
                    spacing="4",
                ),
                socials(),
                justify="between",
                width="100%",
                flex_direction=["column", "column", "row"],
                align_items="center",
            ),
            spacing="6",
            width="100%",
            max_width="1400px",
            margin="0 auto",
            padding_x="4",
            padding_y="8",
            ## Added extra padding to the top
        ),
        width="100vw",
        margin_left="calc(-50vw + 50%)",
        margin_right="calc(-50vw + 50%)",
        margin_top="8em",
        bg="gray.100",
        # box_shadow="0 -4px 6px -1px rgba(0, 0, 0, 0.1), 0 -2px 4px -1px rgba(0, 0, 0, 0.06)"  # Added top shadow
        border_top="1px solid #E2E8F0"  # Added thin light grey border on top
    )
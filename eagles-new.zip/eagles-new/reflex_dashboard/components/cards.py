"""This module contains the functions to create the custom component cards for the workspace, project, and collection"""
import reflex as rx
from reflex_dashboard.state import State
from reflex_dashboard.components.dialogs import update_workspace_dialog, delete_workspace_dialog, update_project_dialog
from reflex_dashboard.models import Workspace

def dir_card_desc(title:str) -> rx.Component:
        val = title
        if title == "Workspace":
            val = "Projects"
        elif title == "Project":
            val = "Collections"
        elif title == "Collection":
            val = "Files"
        return rx.text(val, size="3", color=rx.color("gray", 10),)
    
# to show the edit button for each workspace card
def update_workspace_button(id:int) -> rx.Component:
    State.get_workspaces(id)
    workspace_object_to_update = State.this_workspace
    # print(f"cards.py the update_workspace_button: , {workspace_object_to_update} \n")
    return update_workspace_dialog(workspace_object_to_update)

def dir_card(icon:str, # the icon for card
             card_type:str, # the type of card ie. workspace, project, collection
             title:str,  # the title of the card
             subtitle:str, # the description of the card
             icon_color:str, # the color of the icon
             total:int, # the total number of items in the card
             id:int) -> rx.Component: # the id of the card
    return rx.card(
        rx.hstack(
            rx.vstack(
                rx.hstack(
                    rx.hstack(
                        rx.icon(
                            tag=icon,
                            size=22,
                            color = rx.color(icon_color, 11),
                        ),
                        rx.text(
                            title,
                            size="4",
                            weight="medium",
                            color=rx.color("gray", 11),
                        ),
                        update_dialog(card_type, id),
                        delete_button(card_type, id),
                        spacing="2",
                        align="center",
                    ),
                    justify="between",
                    width="100%",
                ),
                rx.hstack(
                    rx.heading(
                        f"{total}",
                        size="7",
                        weight="bold",
                    ),
                    # need to fix this value to be dynamic
                    dir_card_desc(card_type),
                    spacing="2",
                    align_items="end",
                ),
                align_items="start",
                justify="between",
                width="100%",
            ),
            align_items="start",
            width="100%",
            justify="between",
        ),
        size="3",
        width="100%",
        max_width="22rem",
    )
    
# to show the workspace card for each workspace
def dir_card_workspaces(
        workspace_id:int,
        title:str,
        project_count:int,
        ) -> rx.Component:
    return rx.card(
        rx.hstack(
            rx.vstack(
                rx.hstack(
                    rx.hstack(
                        rx.icon(
                            tag="package-open",  # Assuming a default icon for workspaces
                            size=22,
                            color=rx.color("crimson", 11),  # Using crimson as default color
                        ),
                        rx.link(  # Wrap the title in a link
                            rx.text(
                                title,
                                size="4",
                                weight="medium",
                                color=rx.color("gray", 11),
                            ),
                            href=f"/workspace/{workspace_id}",  # Set the href to the dynamic route
                            # style={"text_decoration": "bold"},  # Optional: remove underline
                        ),
                        spacing="2",
                        align="center",
                    ),
                    rx.hstack(
                        update_workspace_dialog(workspace_id),
                        delete_workspace_dialog(workspace_id),
                    ),
                    justify="between",
                    width="100%",
                ),
                rx.hstack(
                    rx.heading(
                        f"{project_count}",
                        size="7",
                        weight="bold",
                    ),
                    dir_card_desc("Workspace"),
                    spacing="2",
                    align_items="end",
                ),
                align_items="start",
                justify="between",
                width="100%",
            ),
            align_items="start",
            width="100%",
            justify="between",
        ),
        style={"_hover": {"bg": rx.color("gray", 3)}},
        size="3",
        width="100%",
        max_width="22rem",
    )
    
    
def dir_card_projects(
        project_id:int,
        title:str,
        collection_count:int,
        ) -> rx.Component:
    return rx.card(
        rx.hstack(
            rx.vstack(
                rx.hstack(
                    rx.hstack(
                        rx.icon(
                            tag="package",  # Assuming a default icon for projects
                            size=22,
                            color=rx.color("blue", 11),  # Using blue as default color
                        ),
                        rx.link(  # Wrap the title in a link
                            rx.text(
                                title,
                                size="4",
                                weight="medium",
                                color=rx.color("gray", 11),
                            ),
                            href=f"/project/{project_id}",  # Set the href to the dynamic route
                            # style={"text_decoration": "bold"},  # Optional: remove underline
                        ),
                        spacing="2",
                        align="center",
                        
                    ),
                    rx.hstack(
                        update_project_dialog(project_id),
                        # delete_project_dialog(project_id),
                    ),
                    justify="between",
                    width="100%",
                ),
                rx.hstack(
                    rx.heading(
                        f"{collection_count}",
                        size="7",
                        weight="bold",
                    ),
                    dir_card_desc("Project"),
                    spacing="2",
                    align_items="end",
                    justify="between",
                    width="100%",
                ),
                align_items="start",
                justify="between",
                width="100%",
            ),
            align_items="start",
            width="100%",
            justify="between",
        ),
        style={"_hover": {"bg": rx.color("gray", 3)}},
        size="3",
        width="100%",
        max_width="22rem",
    )

import reflex as rx
from sqlmodel import select, func
import os
from langchain_community.document_loaders import PyPDFLoader
from langchain_chroma import Chroma
import chromadb
from langchain_text_splitters import RecursiveCharacterTextSplitter
from chromadb.utils.embedding_functions import OpenAIEmbeddingFunction
from langchain_community.embeddings.sentence_transformer import (
    SentenceTransformerEmbeddings,
)

import logging

from reflex_dashboard.models import User, Workspace, Project, Collection, Doc_file
############ADDED BY ROHIT#########################################################

import re  # Regular expressions for pattern matching
import hashlib  # Hashing library for password hashing
import os  # OS library for generating salts
from sqlmodel import Field, SQLModel, create_engine, Session, select  # SQLModel for database operations
from sqlmodel import Relationship

from typing import Optional, List

#####################################################################

logger = logging.getLogger("eagles")
logger.addHandler(logging.NullHandler())
logger.setLevel(40)

os.environ["OPENAI_API_KEY"] = "sk-proj-wk9rCD7XyzZ3cy4ycPw9T3BlbkFJYPOBzdyh8xEJXRONaRrM"
OPENAI_API_KEY = "sk-proj-wk9rCD7XyzZ3cy4ycPw9T3BlbkFJYPOBzdyh8xEJXRONaRrM"
# os.environ["DISABLE_NEST_ASYNCIO"] = "True"

class UploadedFile(rx.Model, table=True):
    name: str
    type: str
    size: int
    isIndexed: bool

#########ADDED BY ROHIT#######################################################
# This class is used to create the database table for users
# class User(SQLModel, table=True):
#     id: int = Field(default=None, primary_key=True)
#     full_name: str              #need to check if change of variable name effects used full_name instead of name
#     mobile_number: str
#     email: str
#     password: str
#     salt: str
#     ## Define a relationship between the User and Workspace classes (one-to-many)
#     workspaces: List["Workspace"] = Relationship(back_populates="user") # Define a relationship between the User and Workspace classes (one-to-many)


# ##########Some Extra classes to make the table-structure#######################

# # class User(rx.Model, table=True):   # Define a SQLModel class    #this class is already declared
# #     id: Optional[int] = Field(default=None, primary_key=True)   # Define a primary key column
# #     name: str
# #     email: str
    
#     # a user has many workspaces
# #   workspaces: List["Workspace"] = Relationship(back_populates="user") # Define a relationship between the User and Workspace classes (one-to-many)

# class Workspace(rx.Model, table=True):
#     id: Optional[int] = Field(default=None, primary_key=True)
#     name: str
    
#     #a workspace belongs to a user
#     user_id: int = Field(foreign_key="user.id") # Define a foreign key relationship between the Workspace and User classes
#     user: User = Relationship(back_populates="workspaces") # Define a relationship between the Workspace and User classes (many-to-one)
    
#     #a workspace has many projects
#     projects: List["Project"] = Relationship(back_populates="workspace") # Define a relationship between the Workspace and Project classes (one-to-many)

# class Project(rx.Model, table=True):   # Define a SQLModel class                         
#     id: Optional[int] = Field(default=None, primary_key=True) 
#     name: str
#     # description: Optional[str] = None
    
#     #a project belongs to a workspace
#     workspace_id: int = Field(foreign_key="workspace.id") # Define a foreign key relationship between the Project and Workspace classes
#     workspace: Workspace = Relationship(back_populates="projects") # Define a relationship between the Project and Workspace classes (many-to-one)
   
#     #a project has many collections
#     collections: List["Collection"] = Relationship(back_populates="project") # Define a relationship between the Project and Collection classes (one-to-many)

# class Collection(rx.Model, table=True):
#     id: Optional[int] = Field(default=None, primary_key=True)
#     name: str
    
#     #a collection belongs to a project
#     project_id: int = Field(foreign_key="project.id")   # Define a foreign key relationship between the Collection and Project classes
   
#     project : Project = Relationship(back_populates="collections") # Define a relationship between the Collection and Project classes (many-to-one)
   
#     #a collection has many doc_files
#     doc_files : List["Doc_file"] = Relationship(back_populates="collection")  

# class Doc_file(rx.Model, table=True):
#     id: Optional[int] = Field(default=None, primary_key=True)
#     name: str
#     # file_path: str
#     # des: Optional[str] = None
    
#     #a doc_file belongs to a collection
#     collection_id: int = Field(foreign_key="collection.id") # Define a foreign key relationship between the Doc_files and Collection classes
#     collection : Collection = Relationship(back_populates="doc_files") # Define a relationship between the Doc_files and Collection classes (many-to-one)
    

# # engine = create_engine("sqlite:///database.db", echo=True) # echo=True will print all SQL queries to the terminal
# # SQLModel.metadata.create_all(engine)    # Create the database schema for all the SQLModel classes



# ##############END#################################################################


# # Define the database URL and create the engine
# # engine = create_engine("sqlite:///database.db", echo=True)
# DATABASE_URL = "sqlite:///./test.db"
# # engine = create_engine(DATABASE_URL, echo=True)

# # Create the database tables
# SQLModel.metadata.create_all(engine)
# ##############################################################################
############################################################################


class State(rx.State):
    pass
    img: list[str] = []
    isFiles: bool
    uploadedFiles: list[UploadedFile] = []
    indexedFiles: list[UploadedFile] = []
    documents: dict[str, str]
    currentParsingFileName: str = " "
    fileText: str = ""
    #submitButtonDisable: bool = False
    
    current_logged_in_user: User = User() # to store the current logged in user
    current_logged_in_user_id: Optional[int] = None # to store the current logged in user id
    
    project_list_with_count: list[dict] = []  # to store the project count per workspace
    this_workspace : Workspace = Workspace() # to store the workspace data from get_workspace_by_id
    workspaces_for_user: list[Workspace] = [] # to store the workspaces for a user

    collection_list_with_count: list[dict] = []  # to store the collection count per project
    
    
    def cleanup(self):
        self.fileText = "On successfull processing,file content in text format will be displayed here. Click Start Processing. "
        
    def update_text(self):
        self.fileText = ""
        #self.submitButtonDisable = True
        self.fileText = self.parseFile()
        #self.submitButtonDisable = False
        return rx._x.toast.info(f"file {self.currentParsingFileName} has been successfully parsed!.", variant="outline",
                                position="bottom-right")

    def qa(self, question: str):
        return "I dont know"

    def isFilesExist(self) -> bool:
        if len(self.uploadedFiles) > 0:
            return True
        else:
            return False

    def delete_file(self, id: int):

        """Delete a file from the database and location."""

        with rx.session() as session:
            tobedeletedfile = session.exec(
                select(UploadedFile).where(UploadedFile.id == id)).first()
            session.delete(tobedeletedfile)
            session.commit()

            # delete form folder
        file_path = os.path.join(rx.get_upload_dir(), tobedeletedfile.name)
        if os.path.exists(file_path):
            os.remove(file_path)
        # remove file form vector DB
        self.removeVectorfromDB(file_path)
        self.QueryUploadedFiles()
        self.QueryIndexedFiles
        return rx._x.toast.info(f"file {UploadedFile.name} has been deleted.", variant="outline",
                                position="bottom-right")

    def QueryUploadedFiles(self):
        with rx.session() as session:
            self.uploadedFiles = session.exec(UploadedFile.select()).all()

    def QueryIndexedFiles(self):
        with rx.session() as session:
            self.indexedFiles = session.exec(UploadedFile.select().where(UploadedFile.isIndexed == True)).all()

    async def handle_upload(self, files: list[rx.UploadFile]):
        """Handle the upload of file(s).

        Args:
            files: The uploaded files.
        """
        for file in files:
            upload_data = await file.read()
            outfile = rx.get_upload_dir() / file.filename

            # Save the file.
            with outfile.open("wb") as file_object:
                file_object.write(upload_data)
            # store the file data in db

            with rx.session() as session:
                session.add(
                    UploadedFile(
                        name=file.filename,
                        type=file.content_type,
                        size=file.size,
                        isIndexed=False
                    )
                )
                session.commit()
            # Update the img var.
            self.img.append(file.filename)
        self.QueryUploadedFiles()
        return rx._x.toast.info(f"file has been successfully uploaded.", variant="outline", position="bottom-right")

    # implementation with langchain
    def parseFile(self) -> str:

        file_path = os.path.join(rx.get_upload_dir(), self.currentParsingFileName)
        if os.path.exists(file_path):
            loader = PyPDFLoader(file_path)
            docs = loader.load()
            text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000, chunk_overlap=200, add_start_index=True)
            pages = text_splitter.split_documents(docs)
            # Store in chroma vectordb
            concatenated_content = ""
            for page in pages:
                concatenated_content += page.page_content + " "
            indexeddoc = self.storeDocInVectorDB(pages, self.currentParsingFileName)
            print(f"No of document index ={indexeddoc}")
            self.documents[self.currentParsingFileName] = concatenated_content

            # update db
            with rx.session() as session:
                dbInstance = session.exec(
                    UploadedFile.select().where(
                        (UploadedFile.name == self.currentParsingFileName)
                    )
                ).first()
            dbInstance.isIndexed = True
            session.add(dbInstance)
            session.commit()

            return concatenated_content

    def storeDocInVectorDB(self, pages, filename: str) -> int:
        #embedding_function = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
        embedding_function = OpenAIEmbeddingFunction(api_key=OPENAI_API_KEY,model_name="text-embedding-3-small")
        persistent_client = chromadb.PersistentClient("./vector_store")
        collection = persistent_client.get_or_create_collection("egales3_pdf",embedding_function=embedding_function)
        i = 0       
        for doc in pages:
             i = i + 1
             collection.add(
                ids=[f"{filename}-{i}"], metadatas=doc.metadata, documents=doc.page_content

            )
        langchain_chroma = Chroma(
            client=persistent_client,
            collection_name="egales3_pdf",
            embedding_function=embedding_function,
        )
        return langchain_chroma._collection.count()

    def removeVectorfromDB(self, filepath: str):
        #embedding_function = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
        persistent_client = chromadb.PersistentClient("./vector_store")
        embedding_function = OpenAIEmbeddingFunction(api_key=OPENAI_API_KEY,model_name="text-embedding-3-small")        
        langchain_chroma = Chroma(
            client=persistent_client,
            collection_name="egales3_pdf",
            embedding_function=embedding_function,
        )

        search_doc = (langchain_chroma.get(where={"source": filepath}))
        if len(search_doc.get("ids")) > 0:
            langchain_chroma.delete(ids=search_doc.get("ids"))
        else:
            print("No vector found")

    def redirect_page(self, name: str):
        self.currentParsingFileName = name
        dynamic_url = f"/parse/{name}"
        return rx.redirect(dynamic_url)






#############################################################################################
#######THESE FUNCTIONS ARE  ADDED BY ROHIT###################################################
#############################################################################################

    # User details and error messages
    full_name: str = ""
    mobile_number: str = ""
    mobile_error_message: str = ""
    email: str = ""
    email_error_message: str = ""
    password: str = ""
    confirm_password: str = ""
    password_error_message: str = ""
    error_message: str = ""

    # Login details and error messages
    email_log: str = ""
    password_log: str = ""
    error_message_log: str = ""

    # Password reset details and error messages
    email_forget: str = ""
    email_verified: bool = False
    reset_error_message: str = ""

    password_set: str = ""
    confirm_password_set: str = ""
    error_message_set: str = ""
    password_set_error_message: str = ""

    ##storing the current user's email id.
    logged_in_email: str = rx.LocalStorage()   
    ##storing the current user's name.
    #logged_in_name: str = rx.LocalStorage(default="No user")

    #function to refresh errors
    def RefreshErrorMsg(self):
        self.error_message_set: str = ""
        self.password_set_error_message: str = ""
        self.reset_error_message: str = ""
        self.error_message_log: str = ""
        self.password_error_message: str = ""
        self.error_message: str = ""
        self.mobile_error_message: str = ""
        self.email_error_message: str = ""



    # Functions for storing entered details
    def set_full_name(self, value: str):
        self.full_name = value

    def set_mobile_number(self, value: str):
        self.mobile_number = value
        self.validate_mobile_number()

    def set_email(self, value: str):
        self.email = value
        self.validate_email()

    def set_password(self, value: str):
        self.password = value

    # Function to validate the password
    def validate_password(self):
        password_pattern = r'^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$'
        if not re.match(password_pattern, self.password):
            self.password_error_message = "Password must be at least 8 characters long and contain both letters and numbers."
            return False
        else:
            self.password_error_message = ""
            return True

    # Function to validate the email
    def validate_email(self):
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(email_pattern, self.email):
            self.email_error_message = "Invalid email format. Must be sometext@mail.com."
        else:
            self.email_error_message = ""

    # Function to validate the mobile number
    def validate_mobile_number(self):
        if len(self.mobile_number) != 10 or not self.mobile_number.isdigit():
            self.mobile_error_message = "Mobile number must be exactly 10 digits."
        else:
            self.mobile_error_message = ""

    # Function for hashing password
    def hash_password(self, password: str, salt: str) -> str:
        return hashlib.sha256((password + salt).encode('utf-8')).hexdigest()

    # Function to generate a salt
    def generate_salt(self) -> str:
        return os.urandom(16).hex()

    # Function to handle user signup
    def handle_signup_submit(self):
        # Validate mobile number
        self.validate_mobile_number()
        # Validate email format
        self.validate_email()
        # Check if the password meets the criteria
        password_check = self.validate_password()
        
        if password_check:
            # Check if any required field is missing
            if not self.full_name or not self.mobile_number or not self.email or not self.password:
                self.error_message = "Please enter all the details"
                return
            
            # Check if there is an error in the mobile number
            if self.mobile_error_message:
                return
            
            # Generate a salt for password hashing
            salt = self.generate_salt()
            # Hash the password with the generated salt
            hashed_password = self.hash_password(self.password, salt)

            # Start a new database session
            with rx.session() as session:
                # Create a new User object with the provided details
                new_user = User(
                    full_name=self.full_name,
                    mobile_number=self.mobile_number,
                    email=self.email,
                    password=hashed_password,
                    salt=salt,
                )
                # Add the new user to the database session
                session.add(new_user)
                # Commit the transaction to save the new user in the database
                session.commit()
                # Refresh the session to get the updated user object
                session.refresh(new_user)

            # Set the success message after signup
            self.error_message = "Signup successful!"
            # Retrieve all users to verify the stored data
            self.get_users()
            # Redirect to the login page
            return rx.redirect('/TryLogin')

    # Function to retrieve all users from the database
    def get_users(self):
        with rx.session() as session:
            self.users = session.query(User).all()
            for user in self.users:
                print(f"User: {user.full_name}, Email: {user.email}, Mobile: {user.mobile_number},Password: {user.password}")

    # Function to validate the new password
    def validate_password_set(self):
        password_pattern = r'^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$'
        if not re.match(password_pattern, self.password_set):
            self.password_set_error_message = "Password must be at least 8 characters long and contain both letters and numbers."
            return False
        else:
            self.password_set_error_message = ""
            return True

    # Function to check if the passwords match
    def check_passwords(self):
        if self.validate_password_set():
            if self.password_set != self.confirm_password_set:
                self.error_message_set = "Passwords do not match"
                return False
            else:
                self.error_message_set = ""  # Clear the error message if they match
                return True

    # Function to update the user password
    def update_password(self):
        salt = self.generate_salt()
        hashed_password = self.hash_password(self.password_set, salt)
        with rx.session() as session:
            statement = select(User).where(User.email == self.email_forget)
            user = session.exec(statement).first()
            if user:
                user.password = hashed_password
                user.salt = salt
                session.add(user)
                session.commit()
                session.refresh(user)
                self.error_message_set = "Password updated successfully!"
            else:
                self.error_message_set = "User not found!"

    # Function to handle password reset submission
    def handle_setpass_submit(self):
        if self.check_passwords():
            if not self.error_message_set:
                self.update_password()
                return rx.redirect('/loginpage')

    # Function to handle user login
    def handle_login_submit(self):
        # Check if the email or password fields are empty
        if not self.email_log or not self.password_log:
            self.error_message_log = "Please enter all the details"
            return

        # Start a new database session
        with rx.session() as session:
            # Query the database for a user with the provided email
            statement = select(User).where(User.email == self.email_log)
            user = session.exec(statement).first()
            
            # Check if the user exists and the hashed password matches
            if user and self.hash_password(self.password_log, user.salt) == user.password:
                # Set the success message after login
                self.error_message_log = "Login successful!"
                # Store the logged-in user's email
                self.logged_in_email = self.email_log
                self.logged_in_name = user.full_name
                #printing current usser's mail id
                #print(self.logged_in_email)
                rx.console_log("working")
                rx.console_log(self.logged_in_email)
                # Redirect to the logged-in page
                return rx.redirect('/welcome')
            else:
                # Set the error message if the email or password is invalid
                self.error_message_log = "Invalid email or password"


    def handle_logout_click(self):
        # Refresging the logged user mail id
        self.logged_in_email = "No user"
        self.logged_in_name = "No user" 
        #printing current usser's mail id
        #print(self.logged_in_email)
        rx.console_log("working")
        rx.console_log(self.logged_in_email)
        return rx.redirect('/loginpage')
        
    

    # Function to handle email verification for password reset
    def handle_email_verification(self):
        with rx.session() as session:
            statement = select(User).where(User.email == self.email_forget)
            result = session.exec(statement).first()
            if result:
                self.email_verified = True
                self.reset_error_message = ""
                return rx.redirect('/setpassword')
            else:
                self.email_verified = False
                self.reset_error_message = "Email not found"


    def get_logged_in_user_id(self):
        with rx.session() as session:
            # Query the database for the user with the logged-in email
            statement = select(User.id).where(User.email == self.logged_in_email)
            user_id = session.exec(statement).first()
            
            # Check if a user was found
            if user_id:
                # Store the user's ID in the current_logged_in_user_id variable
                self.current_logged_in_user_id = user_id
                rx.console_log(f"Current logged-in user ID: {self.current_logged_in_user_id}")
            else:
                # Reset the current_logged_in_user_id variable if no user is found
                self.current_logged_in_user_id = None
                rx.console_log("No user is currently logged in.")
    ##########################################################################
    #####These are used for the table-structures##############################


    
    # def add_workspace_to_db(self, form_data: dict):
    #     workspace = Workspace(name=form_data["name"], user_id=form_data["user_id"])
    #     with rx.session() as session:
    #         session.add(workspace)
    #         session.commit()
    #         #printing the entire table for testing purpose
    #         users = session.exec(select(Workspace)).all()
    #         for user in users:
    #             print(user)

    #         # session.refresh(self.workspace)
    #     return rx.toast.info(f"Workspace {form_data['name']} has been added.", variant="outline", position="bottom-right") and rx.redirect('/user_projects')
        
    # def add_project_to_db(self, form_data: dict):
    #     project = Project(name=form_data["name"], workspace_id=form_data["workspace_id"])
    #     with rx.session() as session:
    #         session.add(project)
    #         session.commit()
    #         #printing the entire table for testing purpose
    #         users = session.exec(select(Project)).all()
    #         for user in users:
    #             print(user)

    #         # session.refresh(self.Project)
    #     return rx.toast.info(f"Project {form_data['name']} has been added.", variant="outline", position="bottom-right") and rx.redirect('/user_collections')
    

    # def add_collection_to_db(self, form_data: dict):
    #     collection = Collection(name=form_data["name"],project_id=form_data["project_id"])
    #     with rx.session() as session:
    #         session.add(collection)
    #         session.commit()
    #         #printing the entire table for testing purpose
    #         users = session.exec(select(Collection)).all()
    #         for user in users:
    #             print(user)
        
    #         # session.refresh(self.Collection)
    #     # return rx.toast.info(f"Collection {form_data["name"]} has been added.", variant="outline", position="bottom-right") and rx.redirect('/user_docs')
    

    
    # def add_doc_file_to_db(self, form_data: dict):
    #     doc_file = Doc_file(name=form_data["name"], collection_id=form_data["collection_id"])
    #     with rx.session() as session:
    #         session.add(doc_file)
    #         session.commit()
    #         #printing the entire table for testing purpose
    #         users = session.exec(select(Doc_file)).all()
    #         for user in users:
    #             print(user)

    #         # session.refresh(self.doc_file)
    #     # return rx.toast.info(f"Document {form_data['name']} has been added.", variant="outline", position="bottom-right")



    ##########################################################################
    
    def add_collection_to_db(self, form_data: dict):
        collection = Collection(name=form_data["name"],project_id=form_data["project_id"])
        with rx.session() as session:
            session.add(collection)
            session.commit()
            # session.refresh(self.Collection)
        # return rx.toast.info(f"Collection {form_data['name']} has been added.", variant="outline", position="bottom-right")
    
    def add_project_to_db(self, form_data: dict):
        project = Project(name=form_data["name"], workspace_id=form_data["workspace_id"])
        with rx.session() as session:
            session.add(project)
            session.commit()
            # session.refresh(self.Project)
        return rx.toast.info(f"Project {form_data['name']} has been added.", variant="outline", position="bottom-right")

    #sets the current workspace
    def get_workspace (self, workspace: Workspace):
        self.this_workspace = workspace
    
    #to get all the workspaces for a user, useful for the update workspace dialog
    def get_workspace_by_id(self, id: int) -> None:
        with rx.session() as session:
            this_workspace_by_id = session.exec(select(Workspace).where(Workspace.id==id)).first()
            print(f"for the get_wrokspace__by_id , we get workspace: {this_workspace_by_id} \n")
            self.this_workspace = this_workspace_by_id
    
    #to handle form upload and adding workspace to db
    def add_workspace_to_db(self, form_data: dict):
        self.this_workspace = form_data
        this_workspace = Workspace(name=form_data["name"], user_id=self.current_logged_in_user_id)
        with rx.session() as session:
            session.add(this_workspace)
            session.commit()
        self.get_project_count_per_workspace()
        # return rx._x.toast.success(f"Workspace {form_data['name']} has been added.", variant="outline", position="bottom-right")
    
    #to get all the workspaces for a user with respective project count
    def get_project_count_per_workspace(self) -> None:
        with rx.session() as session:
            # Join Workspace and Project tables and count the number of projects per workspace
            project_count = session.exec(
                select(
                    Workspace.id, 
                    Workspace.name,
                    func.coalesce(func.count(Project.id), 0).label("project_count")
                ).outerjoin(Project, Project.workspace_id == Workspace.id)
                    .where(Workspace.user_id == self.current_logged_in_user_id)
                    .group_by(Workspace.id)
            ).all()
            # print(f"project_count: {project_count}")
        self.project_list_with_count= [project_count._asdict() for project_count in project_count]
        print(f"project_list_with_count: {self.project_list_with_count}")
     
    #to update workspace to db
    def update_workspace_to_db(self, form_data: dict):
        print(f"form_data: {form_data}")
        # Assuming self.this_workspace is an instance of Workspace and form_data is a dictionary of attributes to update
        if self.this_workspace is not None:
            with rx.session() as session:
                # Retrieve the workspace again to ensure it's attached to the current session (optional if it's already attached)
                new_workspace = session.exec(
                    select(Workspace).where(Workspace.id == self.this_workspace.id)
                ).first()
                if new_workspace is None:
                    return rx._x.toast("Workspace not found", status="error")
                # Update fields directly
                for field, value in form_data.items():
                    if hasattr(new_workspace, field) and field != "id":  # Ensure the field exists and is not 'id'
                        setattr(new_workspace, field, value)
                session.commit()
                self.get_project_count_per_workspace()
            # # return rx.toast.info(
            #     f"Workspace {form_data['name']} has been updated.",
            #     position="bottom-right",
            #     duration=3000,
            #     status="success",  # You can use "info", "warning", "success", or "error"
            # )
    # def update_workspace_to_db(self, form_data: dict):
    #     print(f"form_data: {form_data}")
    #     self.this_workspace.update(form_data)
    #     with rx.session() as session:
    #         new_workspace = session.exec(
    #             select(Workspace).where(Workspace.id==self.this_workspace["id"])
    #         ).first()
    #         print(f"new_workspace: {new_workspace}")
    #         if new_workspace is None:
    #             return rx._x.toast("Workspace not found", status="error")
    #         for field in Workspace.get_fields():
    #             if field != "id":
    #                 setattr(new_workspace, field, self.this_workspace[field])
    #         session.add(new_workspace)
    #         session.commit()
    #     self.get_project_count_per_workspace(form_data["user_id"])
    #     return rx._x.toast.info(f"Workspace {form_data['name']} has been updated.", variant="outline", position="bottom-right")
    #         # else:
    #         #     return rx._x.toast.error("Workspace not found.", variant="outline", position="bottom-right")
    
    #to delete workspace from db
    def delete_workspace(self, id: int):
        """ Delete a workspace from the database and location."""
        with rx.session() as session:
            to_be_deleted_workspace = session.exec(
                select(Workspace).where(Workspace.id == id)).first()
            check_if_project_exists = session.exec(
                select(Project).where(Project.workspace_id == id)).first()
            # if check_if_project_exists:
                # return rx._x.toast.error(f"Workspace {to_be_deleted_workspace.name} has projects. Please delete the projects first.", variant="outline", position="bottom-right")
            session.delete(to_be_deleted_workspace)
            session.commit()
        self.get_project_count_per_workspace()
        # return rx._x.toast.info(f"Workspace {to_be_deleted_workspace.name} has been deleted.", variant="outline", position="bottom-right")
    
    @rx.var
    def get_workspace_id_for_projectsdash(self) -> str:
        return self.router.page.params.get("workspace_id", None)
    
    def get_collection_count_per_project(self) -> None:
        with rx.session() as session:
            # Join Project and Collection tables and count the number of collections per project
            collection_count = session.exec(
                select(
                    Project.id, 
                    Project.name,
                    func.coalesce(func.count(Collection.id), 0).label("collection_count")
                ).outerjoin(Collection, Collection.project_id == Project.id)
                    .where(Project.workspace_id == self.get_workspace_id_for_projectsdash)
                    .group_by(Project.id)
            ).all()
        self.collection_list_with_count = [collection_count._asdict() for collection_count in collection_count]
        print(f"collection_list_with_count: {self.collection_list_with_count}")
        
    def update_project_to_db(self, form_data: dict):
        print(f"form_data: {form_data}")
        with rx.session() as session:
            # Retrieve the workspace again to ensure it's attached to the current session (optional if it's already attached)
            new_project = session.exec(
                select(Project).where(Project.id == form_data["id"])    
            ).first()
            # Update fields directly
            for field, value in form_data.items():
                if hasattr(new_project, field) and field != "id":
                    setattr(new_project, field, value)
            session.commit()
        self.get_collection_count_per_project()
                        
import reflex as rx
from reflex_dashboard.components import landing_navbar, loginbox_navbar
from reflex_dashboard.components import footer, navbar, try_login

from reflex_dashboard.components import logged_in_box



def logged_in():
    return rx.container(
        navbar.navbar(),
        rx.divider(height='35px', style={"background-color": "white"}),
        logged_in_box.logged_in_box(),
        footer.footer(),

    )
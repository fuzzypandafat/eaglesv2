"""This module contains the components for the index page after login."""

import reflex as rx

from reflex_dashboard.components import navbar_logged_in

from reflex_dashboard.state import State
from reflex_dashboard.components.form_field import form_field
from reflex_dashboard.components.dialogs import add_workspace
from reflex_dashboard.components.cards import dir_card, dir_card_workspaces

# to show the workspace cards group on the workspaces list page
def dir_card_group_workspaces() -> rx.Component:
    # print("the dir_card_group_workspaces is triggered\n")
    State.get_project_count_per_workspace()
    list_of_cards = State.project_list_with_count
    # print(f"the list_of_cards is {list_of_cards}\n")
    cards = rx.foreach(list_of_cards, lambda card: dir_card_workspaces(card["id"],card["name"],card["project_count"]))
    return rx.flex(
        cards,
        spacing="5",
        width="100%",
        wrap="wrap",
        display=["none", "none", "flex"],
        on_mount=lambda: State.get_project_count_per_workspace(),
    )
 

# @rx.page(on_load=[State.get_logged_in_user_id,State.get_project_count_per_workspace()])
def index_after_login() -> rx.Component:
    return rx.vstack(
        navbar_logged_in.navbar(),
        rx.box(
            add_workspace(),
            width="100%",
        ),
        dir_card_group_workspaces(),
        width="100%",
        spacing="6",
        padding_x=["1.5em", "1.5em", "3em"],
    )
    

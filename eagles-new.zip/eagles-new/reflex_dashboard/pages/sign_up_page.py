import reflex as rx
from reflex_dashboard.components import landing_navbar, loginbox_navbar
from reflex_dashboard.components import footer, navbar, sign_up

from reflex_dashboard.components import loginbox


def sign_up_page():
    return rx.container(
        navbar.navbar(),
        rx.divider(height='35px', style={"background-color": "white"}),
        sign_up.sign_up(),
        footer.footer(),

    )
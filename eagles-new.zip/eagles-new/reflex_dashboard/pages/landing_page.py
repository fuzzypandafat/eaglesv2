import reflex as rx
from reflex_dashboard.components import landing_navbar, loginbox_navbar
from reflex_dashboard.components import footer, navbar
from reflex_dashboard.components import loginbox

def landing_page() -> rx.Component:
    return rx.container(        
        # landing_navbar.navbar_buttons(),
        # rx.divider(height='35px', style={"background-color": "white"}),
        # loginbox.logina()
        navbar.navbar(),
        rx.divider(height='35px', style={"background-color": "white"}),
        loginbox_navbar.home(),
        footer.footer(),
    )

import reflex as rx
from reflex_dashboard.components import landing_navbar, loginbox_navbar
from reflex_dashboard.components import footer, navbar, try_login

from reflex_dashboard.components import loginbox




def try_to_login():
    return rx.container(
        navbar.navbar(),
        rx.divider(height='35px', style={"background-color": "white"}),
        try_login.post_signin(),
        footer.footer(),

    )
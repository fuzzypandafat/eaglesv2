import reflex as rx
from reflex_dashboard.components import landing_navbar, loginbox_navbar
from reflex_dashboard.components import footer, navbar, sign_up

from reflex_dashboard.components import user_mail


def check_user():
    return rx.container(
        navbar.navbar(),
        rx.divider(height='35px', style={"background-color": "white"}),
        user_mail.check_user_mail(),
        footer.footer(),

    )
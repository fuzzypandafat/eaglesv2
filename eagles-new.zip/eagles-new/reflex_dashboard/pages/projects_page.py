import reflex as rx

from reflex_dashboard.components import navbar_logged_in

def dir_card_group_projects() -> rx.Component:
    pass


@rx.page(route="/workspace/[workspace_id]")
def projects_page(): #  -> rx.Component:
    return rx.vstack(
        navbar_logged_in.navbar(),
        rx.box(
            # add_project(),
            width="100%",
        ),
        # dir_card_group_workspaces(),
        width="100%",
        spacing="6",
        padding_x=["1.5em", "1.5em", "3em"],
    )
import reflex as rx

# from reflex_dashboard.template import template
from reflex_dashboard.components.parse import parse_file
from reflex_dashboard.navigation import main_navbar 
#####
from reflex_dashboard.components import footer, navbar,navbar_logged_in
#####

# def forget_pass():
#     return rx.container(
#         navbar.navbar(),
#         rx.divider(height='35px', style={"background-color": "white"}),
#         forgetbox(),
#         footer.footer(),

#     )


#@template
def parse() -> rx.Component:
    """The main app."""
    return rx.container(
        navbar_logged_in.navbar(),
        rx.chakra.vstack(
            #main_navbar(heading="Extract information from files"),
            parse_file(),
            rx.spacer(),
            background_color=rx.color("mauve", 1),
            color=rx.color("mauve", 12),
            min_height="100vh",
            align_items="stretch",
            spacing="2",
            padding="4em"
        ),
        footer.footer(),
    )

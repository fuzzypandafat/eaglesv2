import reflex as rx
from reflex_dashboard.state import State

from reflex_dashboard.navigation import main_navbar
#from reflex_dashboard.template import template
#####
from reflex_dashboard.components import footer, navbar, navbar_logged_in
#####

# def forget_pass():
#     return rx.container(
#         navbar.navbar(),
#         rx.divider(height='35px', style={"background-color": "white"}),
#         forgetbox(),
#         footer.footer(),

#     )



color = "rgb(107,99,246)"


def _header_cell(text: str, icon: str):
    return rx.table.column_header_cell(
        rx.hstack(
            rx.icon(icon, size=18),
            rx.text(text),
            align="center",
            spacing="2",
        ),
    )


#@template
def files() -> rx.Component:
    return rx.container(
        navbar_logged_in.navbar(),
        rx.vstack(
            rx.flex(
                #main_navbar(heading="Upload pdf file to start conversasion"),
                rx.box(
                    rx.text("Upload new pdf files"),
                    margin_top="calc(10px + 2em)",
                    padding="1em",
                )
            ),
            rx.vstack(
                rx.upload(
                    rx.vstack(
                        rx.button("Select File", color=color, bg="white", border=f"1px solid {color}",cursor="pointer"),
                        rx.text("Drag and drop files here or click to select files"),
                    ),
                    id="upload1",
                    border=f"2px dotted {color}",
                    padding="2em",
                    multiple=True,
                    max_files=5,
                    disabled=False,
                    accept={
                        "application/pdf": [".pdf"],
                    }
                ),
                rx.hstack(rx.text("Selected files - "), rx.foreach(rx.selected_files("upload1"), rx.text)),
                rx.hstack(
                    rx.button(
                        "Upload",
                        on_click=State.handle_upload(rx.upload_files(upload_id="upload1")),
                         cursor="pointer", 
                    ),
                    rx.button(
                        "Clear",
                        on_click=rx.clear_selected_files("upload1"),
                        cursor="pointer"
                    )
                ),
                padding="14px",
            ),
            rx.divider(),
            rx.text("List of Uploaded files", padding="14px"),

            rx.divider(),
            rx.table.root(
                rx.table.header(
                    rx.table.row(
                        _header_cell("File Name", "file"),
                        _header_cell("File Type", "file"),
                        _header_cell("File Size", "file"),
                        _header_cell("isIndexed", "file"),
                        _header_cell("Action", "file"),
                        _header_cell("Task", "file")
                    ),
                    style={"_hover": {"bg": rx.color("gray", 3)}},
                    align="center",
                ),
                rx.foreach(State.uploadedFiles, lambda ufiles:
                rx.table.body(
                    rx.table.row(
                        rx.table.row_header_cell(
                            rx.link(ufiles.name,
                                    href=rx.get_upload_url(ufiles.name),
                                    weight="bold",
                                    is_external=True)),
                        rx.table.cell(ufiles.type.split("/")[1]),
                        rx.table.cell(ufiles.size),
                        rx.table.cell(
                            rx.cond(
                                ufiles.isIndexed,
                                rx.text("YES"),
                                rx.text("NO")
                            )
                        ),
                        rx.table.cell(
                            rx.icon_button(
                                rx.icon("trash-2", size=22),
                                on_click=lambda: State.delete_file(getattr(ufiles, "id")),
                                size="2",
                                variant="solid",
                                color_scheme="red",
                                cursor="pointer"
                            )),
                        rx.table.cell(
                            rx.button(
                                "Extract",
                                on_click=lambda: State.redirect_page(getattr(ufiles, "name")),
                                size="2",
                                variant="solid",
                                color_scheme="blue",
                                cursor="pointer"
                            )),
                    ))
                           ),
                variant="surface",
                size="3",
                width="100%",
            ),
        ),
        footer.footer(),

    )

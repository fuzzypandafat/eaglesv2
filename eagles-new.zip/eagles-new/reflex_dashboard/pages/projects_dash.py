import reflex as rx

from reflex_dashboard.components import navbar_logged_in

from reflex_dashboard.state import State
from reflex_dashboard.components.dialogs import add_project
from reflex_dashboard.components.cards import dir_card_projects

def dir_card_group_projects() -> rx.Component:
    State.get_collection_count_per_project()
    list_of_cards = State.collection_list_with_count
    cards = rx.foreach(list_of_cards, lambda card: dir_card_projects(card["id"],card["name"],card["collection_count"]))
    return rx.flex(
        cards,
        spacing="5",
        width="100%",
        wrap="wrap",
        display=["none", "none", "flex"],
        on_mount=lambda: State.get_collection_count_per_project(),
    )


def projects_dash() -> rx.Component:
    return rx.vstack(
        navbar_logged_in.navbar(),
        rx.box(
            add_project(),
            width="100%",
        ),
        dir_card_group_projects(),
        width="100%",
        spacing="6",
        padding_x=["1.5em", "1.5em", "3em"],
    )
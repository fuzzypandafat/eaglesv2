import reflex as rx
from reflex_dashboard.components import landing_navbar, loginbox_navbar
from reflex_dashboard.components import footer, navbar, try_login

from reflex_dashboard.components.user_workspaces import add_workspace



def user_workspaces():
    return rx.container(
        navbar.navbar(),
        rx.divider(height='35px', style={"background-color": "white"}),
        add_workspace(),
        footer.footer(),

    )
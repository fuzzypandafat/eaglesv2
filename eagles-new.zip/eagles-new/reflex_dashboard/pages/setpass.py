import reflex as rx
from reflex_dashboard.components import landing_navbar, loginbox_navbar
from reflex_dashboard.components import footer, navbar, sign_up

from reflex_dashboard.components import setpass_box


def set_pass():
    return rx.container(
        navbar.navbar(),
        rx.divider(height='35px', style={"background-color": "white"}),
        setpass_box.setbox(),
        footer.footer(),

    )
from langchain_openai import AzureChatOpenAI
from langchain_core.messages import HumanMessage
from langchain_core.messages import AIMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
import os
from langchain.memory import ChatMessageHistory
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma
from langchain_openai import  AzureOpenAIEmbeddings
from langchain_community.document_loaders import WebBaseLoader
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_core.messages import HumanMessage
from dotenv import load_dotenv

load_dotenv()
# os.environ["OPENAI_API_KEY"] = "sk-proj-wk9rCD7XyzZ3cy4ycPw9T3BlbkFJYPOBzdyh8xEJXRONaRrM"
# # Checking if the API key is set properly
# if not os.getenv("OPENAI_API_KEY"):
#     raise Exception("Please set OPENAI_API_KEY environment variable.")

# chat = ChatOpenAI(model="gpt-3.5-turbo-1106", temperature=0.2)
if not os.getenv("AZURE_OPENAI_API_KEY"):
    os.environ["AZURE_OPENAI_API_KEY"] = getpass.getpass(
        "Enter your AzureOpenAI API key: "
    )


embeddings = AzureOpenAIEmbeddings(
    # openai_api_type = "azure",
    model = "text-embedding-ada-002",
    # api_key=os.environ["AZURE_OPENAI_API_KEY"],
    # azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    # deployment=os.environ["AZURE_OPENAI_DEPLOYMENT"],
    # openai_api_version=os.environ["AZURE_OPENAI_API_VERSION"],
    
    
    
)

chat = AzureChatOpenAI( temperature=0.2,
                        api_key=os.environ["AZURE_OPENAI_API_KEY"],
                        azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
                        azure_deployment=os.environ["AZURE_OPENAI_DEPLOYMENT"],
                        openai_api_version=os.environ["AZURE_OPENAI_API_VERSION"],
                        )

chat_history = ChatMessageHistory()

chat_history.add_user_message("hi!")

chat_history.add_ai_message("whats up?")

# load document

loader = WebBaseLoader("https://docs.smith.langchain.com/overview")
data = loader.load()
# chunk
text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=0)
all_splits = text_splitter.split_documents(data)

# vector store

vectorstore = Chroma.from_documents(documents=all_splits, embedding=embeddings)

retriever = vectorstore.as_retriever(k=4)

docs = retriever.invoke("how can langsmith help with testing?")

# chat = ChatOpenAI(model="gpt-3.5-turbo-1106")

question_answering_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "Answer the user's questions based on the below context:\n\n{context}",
        ),
        MessagesPlaceholder(variable_name="messages"),
    ]
)

document_chain = create_stuff_documents_chain(chat, question_answering_prompt)
chat_history.add_user_message("how can langsmith help with testing?")

response = document_chain.invoke(
    {
        "messages": chat_history.messages,
        "context": docs,
    }
)

print(response)

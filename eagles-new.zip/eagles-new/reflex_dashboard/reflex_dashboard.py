"""The main Dashboard App."""

from rxconfig import config
from reflex_dashboard.state import State

import reflex as rx

from reflex_dashboard.styles import BACKGROUND_COLOR, FONT_FAMILY, THEME, STYLESHEETS

from reflex_dashboard.pages.ask import tools  #
from reflex_dashboard.pages.uploadFile import files #
from reflex_dashboard.pages.index import index  #
from reflex_dashboard.pages.parse import parse  #
from reflex_dashboard.pages.landing_page import landing_page
from reflex_dashboard.pages.sign_up_page import sign_up_page
from reflex_dashboard.pages.try_to_login import try_to_login
from reflex_dashboard.pages.login import login
from reflex_dashboard.pages.logged_in import logged_in
from reflex_dashboard.pages.forget_box import forget_pass
from reflex_dashboard.pages.setpass import set_pass
from reflex_dashboard.pages.check_user import check_user
from reflex_dashboard.pages.user_workspaces import user_workspaces
from reflex_dashboard.pages.index import index
from reflex_dashboard.pages.index_after_login import index_after_login
from reflex_dashboard.pages.projects_dash import projects_dash

# Create app instance and add index page.
app = rx.App(
    theme=THEME,
    stylesheets=STYLESHEETS,
)

app.add_page(projects_dash, route="/workspace/[workspace_id]")
app.add_page(index_after_login, route="/welcome", on_load=[State.get_logged_in_user_id,State.get_project_count_per_workspace()]) # index after logging in
app.add_page(index, route="/home", on_load=State.QueryIndexedFiles) #
app.add_page(tools, route="/ask") #
app.add_page(files, route="/files", on_load=State.QueryUploadedFiles) #
app.add_page(parse, route="/parse/[name]", on_load = State.cleanup)
app.add_page(landing_page, route="/")
app.add_page(sign_up_page, route="/signUpPage",on_load=State.RefreshErrorMsg)
app.add_page(try_to_login, route="/TryLogin")
app.add_page(login, route="/loginpage",on_load=State.RefreshErrorMsg)
app.add_page(logged_in, route="/loggedInPage")
app.add_page(forget_pass, route="/forgetpass",on_load=State.RefreshErrorMsg)
app.add_page(set_pass, route="/setpassword",on_load=State.RefreshErrorMsg)
app.add_page(check_user, route="/checkUser")
app.add_page(user_workspaces, route="/userWorkspaces")
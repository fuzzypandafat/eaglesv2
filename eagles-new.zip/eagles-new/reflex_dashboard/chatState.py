import os
import json
import reflex as rx
from openai import OpenAI
from langchain_chroma import Chroma
from langchain.chains import RetrievalQA
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain_community.embeddings.sentence_transformer import (
    SentenceTransformerEmbeddings,
)
from chromadb.utils import embedding_functions
import logging
import chromadb
from .qaserver import embeddings, chat as llm

logger = logging.getLogger("eaglesGPT")
logger.addHandler(logging.NullHandler())
logger.setLevel(40)


os.environ["OPENAI_API_KEY"] = "sk-proj-wk9rCD7XyzZ3cy4ycPw9T3BlbkFJYPOBzdyh8xEJXRONaRrM"
# Checking if the API key is set properly
OPENAI_API_KEY = "sk-proj-wk9rCD7XyzZ3cy4ycPw9T3BlbkFJYPOBzdyh8xEJXRONaRrM"

if not os.getenv("OPENAI_API_KEY"):
    raise Exception("Please set OPENAI_API_KEY environment variable.")


class QA(rx.Base):
    """A question and answer pair."""

    question: str
    answer: str


DEFAULT_CHATS = {
    "Intros": [],
}


class chatState(rx.State):
    """The app state."""

    # A dict from the chat name to the list of questions and answers.
    chats: dict[str, list[QA]] = DEFAULT_CHATS

    # The current chat name.
    current_chat = "Intros"

    # The current question.
    question: str

    # Whether we are processing the question.
    processing: bool = False

    # The name of the new chat.
    new_chat_name: str = ""

    def create_chat(self):
        """Create a new chat."""
        # Add the new chat to the list of chats.
        self.current_chat = self.new_chat_name
        self.chats[self.new_chat_name] = []

    def delete_chat(self):
        """Delete the current chat."""
        del self.chats[self.current_chat]
        if len(self.chats) == 0:
            self.chats = DEFAULT_CHATS
        self.current_chat = list(self.chats.keys())[0]

    def set_chat(self, chat_name: str):
        """Set the name of the current chat.

        Args:
            chat_name: The name of the chat.
        """
        self.current_chat = chat_name

    @rx.var
    def chat_titles(self) -> list[str]:
        """Get the list of chat titles.

        Returns:
            The list of chat names.
        """
        return list(self.chats.keys())

    async def process_question(self, form_data: dict[str, str]):
        # Get the question from the form
        question = form_data["question"]

        # Check if the question is empty
        if question == "":
            return
        # openAI function is called here. Need to replacce with the RAG
       # model = self.openai_process_question
        model = self.rag_process_question
        async for value in model(question):
            yield value

    async def openai_process_question(self, question: str):
        """Get the response from the API.

        Args:
            form_data: A dict with the current question.
        """

        # Add the question to the list of questions.
        qa = QA(question=question, answer="")
        self.chats[self.current_chat].append(qa)

        # Clear the input and start the processing.
        self.processing = True
        yield

        # Build the messages.
        messages = [
            {
                "role": "system",
                "content": "You are a friendly chatbot named Reflex. Respond in markdown.",
            }
        ]
        for qa in self.chats[self.current_chat]:
            messages.append({"role": "user", "content": qa.question})
            messages.append({"role": "assistant", "content": qa.answer})

        # Remove the last mock answer.
        messages = messages[:-1]

        # Start a new session to answer the question.
        session = OpenAI().chat.completions.create(
            model=os.getenv("OPENAI_MODEL", "gpt-3.5-turbo"),
            messages=messages,
            stream=True,
        )

        # Stream the results, yielding after every word.
        for item in session:
            if hasattr(item.choices[0].delta, "content"):
                answer_text = item.choices[0].delta.content
                # Ensure answer_text is not None before concatenation
                if answer_text is not None:
                    self.chats[self.current_chat][-1].answer += answer_text
                else:
                    # Handle the case where answer_text is None, perhaps log it or assign a default value
                    # For example, assigning an empty string if answer_text is None
                    answer_text = ""
                    self.chats[self.current_chat][-1].answer += answer_text
                self.chats = self.chats
                yield

        # Toggle the processing flag.
        self.processing = False


    def format_docs(self,docs:str):
        full_docs = "\n\n".join(doc.documents for doc in docs)
        return full_docs

    from langchain_core.output_parsers import StrOutputParser
    async def rag_process_question(self, question: str):
        """Get the response from the API.

        Args:
            form_data: A dict with the current question.
        """

        # Add the question to the list of questions.
        qa = QA(question=question, answer="")
        self.chats[self.current_chat].append(qa)

        # Clear the input and start the processing.
        self.processing = True
        yield
        
        """
        Adding code for getting doctument form chroma collection
        
        """
        
        #embedding_function = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
        persistent_client = chromadb.PersistentClient("./vector_store")
        persist_directory = './vector_store'
        # embedding_function = embedding_functions.OpenAIEmbeddingFunction(api_key=OPENAI_API_KEY,model_name="text-embedding-3-small")
        embedding_function = embeddings
        # llm = ChatOpenAI(model="gpt-3.5-turbo")
        
        #client = chromadb.Client()
        collection = persistent_client.get_collection(name="egales3_pdf",embedding_function=embedding_function)
        
        docs = collection.query(
            query_texts=[question],            
        )
        
        #vectordb = Chroma(collection_name="egales3_pdf",persist_directory=persist_directory, embedding_function=embedding_function)
        #retriever = vectordb.as_retriever(search_type="similarity", search_kwargs={"k": 4})
        all_documents = ' '.join(doc for doc_list in docs['documents'] for doc in doc_list)


      #  docs = langchain_chroma.similarity_search(question)
        template_new = f"""Use the following pieces of context to answer the question at the end.
            If you don't know the answer, just say that you don't know, don't try to make up an answer.
            Use three sentences maximum. Keep the answer as concise as possible. Always return the answer 
            in markdown format.

            Context: {all_documents}

            Question: {question}

            Helpful Answer:"""
            
        
          
        chunks = []
        async for chunk in llm.astream(template_new):
            chunks.append(chunk)           
            if chunk.content is not None:
                        self.chats[self.current_chat][-1].answer += chunk.content
            else:
                answer_text = ""
                self.chats[self.current_chat][-1].answer += answer_text
                self.chats = self.chats
                yield    
        self.processing = False   

"""The style classes and constants for the Dashboard App."""

from reflex.components.radix import themes as rx

THEME = rx.theme(
    appearance="light",
    theme_panel= False,
    has_background=True,
    radius="large",
    #accent_color="brown",
    scaling="100%",
    panel_background="solid",
)

STYLESHEETS = ["https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap"]

FONT_FAMILY = ""
BACKGROUND_COLOR = "var(--accent-2)"

